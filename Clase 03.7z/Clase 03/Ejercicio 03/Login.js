"use strict";
//Utilizar el localStorage, se guarda informacion dentro de alli
//Tiene dos metodos, uno para guardar y otro para obtener cosas
//Buscamos guardar informacion, recibe dos parametros, lo unico que voy a poder guardar es texto(string)
//Hay que chequear para que no me pisen los datos
//if(localStorage.getItem("Empleados") == null)//Me devuelve el string asociado a esa clave o null si no lo encuentra
//{
localStorage.setItem("Empleados", "Juan-123,Rosa-456,Carlos-666"); //Nuestro primer empleado
//}
function Loguear() {
    var nombre = document.getElementById("txtNombre").value;
    var legajo = document.getElementById("txtLegajo").value;
    //let valores = localStorage.getItem("Empleados") == null ? "" :localStorage.getItem("Empleados");//Me devuelve el string asociado a esa clave o null si no lo encuentra
    var valores = localStorage.getItem("Empleados");
    //Tengo que particionar un string, utilizar split
    var encontrado = false;
    if (valores != null) {
        var array_emp = valores.split(",");
        for (var i = 0; i < array_emp.length; i++) {
            var array_cosas = array_emp[i].split("-");
            if (nombre == array_cosas[0] && legajo == array_cosas[1]) {
                console.log("Exito! \n El usuario esta registrado");
                encontrado = true;
                window.location.href = "./Principal.html";
                break;
            }
        }
    }
    if (encontrado == false) {
        console.log("No se encontro!");
        alert("Lo sentimos, el usuario que ingreso no existe, vuelva en otro momento.");
    }
}
//va ser una base de datos
//Todos los empleados cargados vas a ser guardados  
//# sourceMappingURL=Login.js.map