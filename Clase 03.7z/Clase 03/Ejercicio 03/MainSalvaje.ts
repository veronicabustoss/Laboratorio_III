/// <reference path="./Empleados.ts" />
let emp = new Entidades.Empleado("Carlos","Bustamante",5234664,"M",14502,45000);

console.log(emp.ToString());
console.log(emp.Hablar("Japones"));