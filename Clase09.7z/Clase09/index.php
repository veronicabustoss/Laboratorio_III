<?php
use \Psr\Http\Message\ServerRequestInterface as Request;
use \Psr\Http\Message\ResponseInterface as Response;

require_once './vendor/autoload.php';

$config['displayErrorDetails'] = true;
$config['addContentLengthHeader'] = false;

/*
�La primera l�nea es la m�s importante! A su vez en el modo de 
desarrollo para obtener informaci�n sobre los errores
 (sin �l, Slim por lo menos registrar los errores por lo que si est� utilizando
  el construido en PHP webserver, entonces usted ver� en la salida de la consola 
  que es �til).

  La segunda l�nea permite al servidor web establecer el encabezado Content-Length, 
  lo que hace que Slim se comporte de manera m�s predecible.
*/

$app = new \Slim\App(["settings" => $config]);

$app->get('[/]', function (Request $request, Response $response) {    
    $response->getBody()->write("GET => Bienvenido!!! a SlimFramework");
    return $response;

});


/*
COMPLETAR POST, PUT Y DELETE
*/
$app->post('[/]', function (Request $request, Response $response) {    
    $response->getBody()->write("POST => Bienvenido!!! a SlimFramework");
    return $response;

});

$app->put('[/]', function (Request $request, Response $response) {    
    $response->getBody()->write("PUT => Bienvenido!!! a SlimFramework");
    return $response;

});

$app->delete('[/]', function (Request $request, Response $response) {    
    $response->getBody()->write("DELETE => Bienvenido!!! a SlimFramework");
    return $response;

});

//Recibe parametros POR GET
$app->get('/parametros/{nombre}/[{apellido}]', function (Request $request, Response $response,$args) {  //Poner argumentos para que se pueda mostrar luego el nombre
    $nombre =  $args['nombre'];

    if(isset($args['apellido']))//Confirmamos si el apellido vino cargado o no
    {
        $apellido = $args['apellido'];//Si vino cargado lo definimos
        $response->getBody()->write("¡Bienvenido ".$nombre." ".$apellido."!");
    }
    else
    {
        $response->getBody()->write("¡Bienvenido ".$nombre."(Solo con nombre)!");
    }
   
    return $response;

});

//Por POST le pasamos parametros
$app->post('/parametros/[{nombre}]', function (Request $request, Response $response,$args) {  //Poner argumentos para que se pueda mostrar luego el nombre
    $nombre =  $args['nombre'];
    $response->getBody()->write("Bienvenido ".$nombre."!");
    return $response;

});


//Utilizamos Grupos y le pasamos por Post!!!!!
$app->group('/json',function()
{

    ///Agregar una foto
    $this->post('/',function (Request $request, Response $response)
    {
        $arrayParametros = $request->getParsedBody();
        $archivos = $request->getUploadedFiles();
   
        $nombre= $arrayParametros['nombre'];
        $apellido= $arrayParametros['apellido'];

        $destino="./fotos/";
        $nombreAnterior=$archivos['foto']->getClientFilename();
        $extension= explode(".", $nombreAnterior)  ;
        //var_dump($nombreAnterior);
        $extension=array_reverse($extension);
        $date = date("m.d.y");
        $hms = date("Gis");
        $archivos['foto']->moveTo($destino.$date."_".$hms.".".$extension[0]);
        $response->getBody()->write("Creo que se puso la foto");
        return $response;

    });

    $this->get('/{nombre}/{apellido}',function (Request $request, Response $response,$args)
    {
        $datos = array("nombre" => $args['nombre'],"apellido" => $args['apellido'],);
        //$arrayParametros = $request->getParsedBody();
        $newResponse = $response->withJson($datos,200);
        return $newResponse;
    });

    $this->delete('/',function (Request $request, Response $response)
    {
        $arrayParametros = $request->getParsedBody();
        $jsonTomado = json_decode($arrayParametros['json']);
        $obj = new stdClass();
        $obj->nombre = $jsonTomado->apellido;
        $obj->apellido = $jsonTomado->nombre;
        $newResponse = $response->withJson($obj,200);
        return $newResponse;

    });

});



$app->run();//Si esta linea no esta ejecutada, ningun verbo se ejecutara, si no esta esto, no funciona nada