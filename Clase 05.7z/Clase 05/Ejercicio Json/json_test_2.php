<?php

//$idAutos = isset($_POST["idAuto"])  ? $_POST["idAuto"] :NULL;

$archivo = fopen("./archivos/autos.json","r");

$archivoLeido = fread($archivo,filesize("./archivos/autos.json"));

fclose($archivo);

//DECODEO A JSON, EL ARRAY LEIDO (GENERANDO UN ARRAY DE OBJETOS PHP)

echo $archivoLeido;


//Generar una tabla de html y poner nuestros objetos recuperados 
?>