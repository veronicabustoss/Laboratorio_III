<?php

//var_dump($_POST);

$producto = json_decode($_POST["producto"]);

$producto->Precio = 55.66;
$producto->codigo_barra = "TRF775";
$producto->Nombre = "Nami";

echo json_encode($producto);

//echo $producto->precio." ".$producto->codigo_barra." ".$producto->nombre;

?>