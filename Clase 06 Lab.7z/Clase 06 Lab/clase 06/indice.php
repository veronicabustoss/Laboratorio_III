<?php

//Genero un switch para poner todos los casos
$corre = isset($_POST["correo"]) ? $_POST["correo"] : NULL;
$clave =  isset($_POST["clave"]) ? $_POST["clave"] : NULL;

//usiario_login = {}
//Le paso un JSON desde PostMan


?>